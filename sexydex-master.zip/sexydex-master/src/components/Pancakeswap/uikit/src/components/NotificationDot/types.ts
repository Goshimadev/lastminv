export interface NotificationDotProps {
  show?: boolean;
  children: React.ReactElement | React.ReactElement[];
}

export interface DotProps {
  show: boolean;
}
